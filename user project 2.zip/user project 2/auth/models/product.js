const mongoose = require('mongoose'), Schema = mongoose.Schema;

const ProductSchema = mongoose.Schema({
    code: String,
    name: String,
    details: String,
    image: String,
    price: Number
});

module.exports = mongoose.model('Product', ProductSchema);
