module.exports = function (app) {
  var products = require('../controllers/product.controller');

  // Find all products
  app.get('/api/products', products.findAll);

  // Find a single Product by Id
  app.get('/api/products/:id', products.findProductById);
}
