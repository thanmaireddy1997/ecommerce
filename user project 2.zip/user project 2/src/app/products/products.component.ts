import { ProductService } from './../services/product.service';
import { Product } from './../models/product';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: Product[];

  constructor(
    private productService: ProductService) { }

    // tslint:disable-next-line: typedef
    ngOnInit() {
      this.getProducts();
    }


    // tslint:disable-next-line: typedef
    getProducts() {
      return this.productService.getProducts()
        .subscribe(
          products => {
            console.log(products);
            this.products = products;
          }
        );
    }
}
