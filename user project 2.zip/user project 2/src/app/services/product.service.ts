import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../models/product';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }),
  ResponseType: 'Product'
};

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private products: Product[];

  private productUrl = 'http://localhost:5000/api/products';
  constructor(private http: HttpClient) { }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.productUrl);
  }

  find(id: string): Product {
    return this.products[this.getSelectedIndex(id)];
}

private getSelectedIndex(id: string): number {
    for (let i = 0; i < this.products.length; i++) {
        // tslint:disable-next-line: triple-equals
        if (this.products[i].code == id) {
            return i;
        }
    }
    return -1;
}
}



