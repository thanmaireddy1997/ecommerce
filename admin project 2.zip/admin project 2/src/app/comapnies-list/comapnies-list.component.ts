import { Company } from './../models/company';
import { CompanyService } from './../services/company.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comapnies-list',
  templateUrl: './comapnies-list.component.html',
  styleUrls: ['./comapnies-list.component.css']
})
export class ComapniesListComponent implements OnInit {

  companies: Company[];

  constructor( private comapnyService: CompanyService) { }

  ngOnInit(): void {
    this.comapnyService.getCompanies().subscribe(result => {
      this.companies = result;
      console.log(this.companies);
    });
  }

}
