import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComapniesListComponent } from './comapnies-list.component';

describe('ComapniesListComponent', () => {
  let component: ComapniesListComponent;
  let fixture: ComponentFixture<ComapniesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComapniesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComapniesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
