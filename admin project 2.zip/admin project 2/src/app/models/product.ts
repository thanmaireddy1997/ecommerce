import { Company } from './company';

export class Product {
    // tslint:disable-next-line: variable-name
    _id: string;
    code: string;
    name: string;
    details: string;
    image: string;
    price: number;
    company: Company = new Company();

}
