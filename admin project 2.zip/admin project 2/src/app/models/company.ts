export class Company {
  // tslint:disable-next-line: variable-name
  _id: string;
  name: string;
}
