import { Product.Ts } from './product';

describe('Product.Ts', () => {
  it('should create an instance', () => {
    expect(new Product.Ts()).toBeTruthy();
  });
});
